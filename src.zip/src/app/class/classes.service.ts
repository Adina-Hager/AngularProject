import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { Class } from './../models/class';
import { Student } from './../models/student';

@Injectable({
  providedIn: 'root'
})
export class ClassesService {

  // Classes$=new  BehaviorSubject<Class[]>([]);

private base = 'https://localhost:44351/api/Classes/';

  constructor(private http:HttpClient) { }
  
  // getClassesList():BehaviorSubject<Class[]>{
  //   if(this.Classes$.value.length===0){
  //    this.setClassesList();
  //   }
  //        return this.Classes$;
  //   }
    
  getClassesList():Observable<Class[]>{
    return this.http.get<Class[]>(`${this.base}GetClassesList`);
  }
    saveStudent(student:Student):Observable<any>{
      return this.http.post(`${this.base}SaveStudent`,student);
  }
        
  getStudentsList():Observable<Student[]>{
    return this.http.get<Student[]>(`${this.base}GetStudentsList`);
  }

  //  setClassesList():void{
  //   this.http.get<Class[]>('https://localhost:44351/api/ClassesControllers/GetClassesList"/Controllers/ClassesControllers/GetClassesList').subscribe(res=>{
  //     this.Classes$.next(res);
  //   })}
}
