import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from 'src/app/models/student';
import { HttpClient} from '@angular/common/http';
import { ClassesService } from './../classes.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-students-list',
  templateUrl: './students-list.component.html',
  styleUrls: ['./students-list.component.css']
})
export class StudentsListComponent implements OnInit {

  StudentsList$=new Observable<Student[]>();

  constructor(private cs:ClassesService, private route:Router) { }

  ngOnInit(): void {
    this.StudentsList$=this.cs.getStudentsList();
  }

  editStudent(student:Student):void{
this.route.navigate(["/shell",student.Id])

  }

}
