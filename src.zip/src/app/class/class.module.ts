import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegistrationComponent } from './registration/registration.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ClassesService } from './classes.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { StudentsListComponent } from './students-list/students-list.component';
import { HighlightDirective } from '../Directives/high-light.directive';
import { ShellComponent } from './shell/shell.component';




const ClassRoutes:Routes=[
  {path:'registration',component:RegistrationComponent},
  {path:'Students-List',component:StudentsListComponent},
  {path:'shell/:student',component:ShellComponent},

]


@NgModule({
  declarations: [
    RegistrationComponent,
    HighlightDirective,
    ShellComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forChild(ClassRoutes),
    CommonModule

  ],
  exports: [RegistrationComponent],
  providers:[ClassesService]
})
export class ClassModule { }
