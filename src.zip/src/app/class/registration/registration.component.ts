import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Student } from './../../models/student';
import { Class } from './../../models/class';

import { ClassesService } from './../classes.service';
import {  Observable } from 'rxjs';
import { ThrowStmt } from '@angular/compiler';
import { textChangeRangeIsUnchanged } from 'typescript';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  @Input()
   student!: Student;
  myForm!:FormGroup;
  color = 'yellow';
 ClassesList!:Class[]
 month!:number;
 class!:number;
 price!:number;
classFlag=false;
monthsFlag=false;
  constructor(private fb: FormBuilder,private cs:ClassesService, private route:Router) { }

  ngOnInit() {
    // ,Validators.pattern('[0-9]*')
    this.myForm = this.fb.group({
      Id:[,[Validators.required,Validators.minLength(9), Validators.maxLength(9)]],
      Name: [,[Validators.required, Validators.minLength(2), Validators.maxLength(24)]],
      Phone:[,[Validators.required,Validators.minLength(9), Validators.maxLength(10),]],
      Address:[,[Validators.required,Validators.minLength(5), Validators.maxLength(20)]],
      Email:[,[Validators.required,Validators.email]],
      Age:[,[Validators.required, Validators.max(99),Validators.min(3)]],
      ClassCode:[,[Validators.required]],
      MonthNumber:[,[Validators.required]],
      Price:[],
    });
   this.myForm.get('Price')?.disable();
    this.myForm.patchValue(this.student);
 
    //this.ClassesList$=this.cs.getClassesList();

   this.cs.getClassesList().subscribe(res=> {
    
     this.ClassesList=res
    },err=>{console.log(err)} );
   
}
valcMonth():void{
this.monthsFlag=true;
if(this.monthsFlag===true&&this.classFlag===true)
  this.calcPrice();
}
valClasses():void{
this.classFlag=true;
if(this.monthsFlag===true&&this.classFlag===true)
  this.calcPrice();
}
calcPrice():void{
  this.class=this.student.ClassCode.Price;
  switch(this.student.MonthNumber){
    case 1:this.price=this.class;break;
    case 3: this.price=this.class*this.student.MonthNumber*0.95;break;
    case 6: this.price=this.class*this.student.MonthNumber*0.85;break;
    case 3: this.price=this.class*this.student.MonthNumber*0.80;break;
   }
   this.student.Price=this.price;
}

onsubmit():void{

  this.cs.saveStudent(this.myForm.value); 
   alert("הנתונים נשמרו בהצלחה");
   this.route.navigateByUrl('/Students-List');

}

}

