import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ClassesService } from '../classes.service';
import { Student } from './../../models/student';

@Component({
  selector: 'app-shell',
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.css']
})
export class ShellComponent implements OnInit {
studenti!:Student[];
data!:string;
selectedStudent!: any;
  constructor(private activeR:ActivatedRoute,private cs:ClassesService) { 
    this.activeR.queryParams.subscribe(params=>
      { 
        this.data=params['student'];
      }
      )
  }
  

  ngOnInit(): void {
   this.cs.getStudentsList().subscribe(res=>{ 
     this.studenti=res
     if(this.studenti!=null)
     this.selectedStudent = this.studenti.find(s => s.Id === this.data);
    })
  }

}


