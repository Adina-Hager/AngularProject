import { Directive, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ClassModule } from './class/class.module';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HomePageComponent } from './home-page/home-page.component';
import { AppRoutingModule } from './app-routing.module';

import { RouterModule } from '@angular/router';
import { HighlightDirective } from './Directives/high-light.directive';


@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent,
    HomePageComponent,
    // HighlightDirective,
  
  ],
  imports: [
    BrowserModule,
    ClassModule, 
    AppRoutingModule,
    RouterModule
  ] ,bootstrap: [AppComponent]

})
export class AppModule { }
