export interface Class {
    Code:number;
    Name:string;
    Price:number;
}
