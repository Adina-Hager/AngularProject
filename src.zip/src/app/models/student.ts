import { Class } from './class';
export interface Student {
    Id:string;
    Name:string;
    Phone:string;
    Address:string;
    Email:string;
    Age:number;
    ClassCode:Class;
    MonthNumber:number;
    Price:number;
}

